package cs4321.project2.operator;

public abstract class LeafOperatorNode extends OperatorNode{
//	private OperatorNode child;
//	public LeafOperatorNode(OperatorNode child) {
//		this.child = child;
//	}
}
