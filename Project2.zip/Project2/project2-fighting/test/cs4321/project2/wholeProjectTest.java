package cs4321.project2;

public class wholeProjectTest {

	public wholeProjectTest() {
		// TODO Auto-generated constructor stub
	}
	
	public static void main(String[] args){
		//how to construct the whole tree structure of the system
	}
}
